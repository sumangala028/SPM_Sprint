public class spm 
{
	
	public static void main(String[] args) {
		String name;
		String address;}
		public class labour extends spm{
			String sid;
			String uni;}
		public class peon extends labour{
			String batch;}
		public class servant extends spm{
			int age;
			int num;
			String portion;
		}
		//public class comment extends spm
		/* public class subcomment extends comment
		 * huihugg
		 */
}